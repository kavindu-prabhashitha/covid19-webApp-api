﻿namespace covid19_api.Dtos.UserRole
{
    public class UpdateUserRoleDto
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
    }
}
