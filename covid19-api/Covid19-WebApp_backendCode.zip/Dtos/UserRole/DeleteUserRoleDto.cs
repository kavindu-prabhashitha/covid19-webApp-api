﻿namespace covid19_api.Dtos.UserRole
{
    public class DeleteUserRoleDto
    {
    }
}
