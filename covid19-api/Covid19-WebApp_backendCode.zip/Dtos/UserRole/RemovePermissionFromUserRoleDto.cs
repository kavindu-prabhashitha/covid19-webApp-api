﻿namespace covid19_api.Dtos.UserRole
{
    public class RemovePermissionFromUserRoleDto
    {
        public int UserRoleId { get; set; }
        public int PermissionId { get; set; }
    }
}
