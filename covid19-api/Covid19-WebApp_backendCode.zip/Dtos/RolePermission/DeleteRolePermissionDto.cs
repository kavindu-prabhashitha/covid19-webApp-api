﻿namespace covid19_api.Dtos.RolePermission
{
    public class DeleteRolePermissionDto
    {
        public int PermissionId { get; set; }
    }
}
